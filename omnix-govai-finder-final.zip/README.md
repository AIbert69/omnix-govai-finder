# Omnix | GovAI — Hosted SAM.gov Finder (No CORS)

Deploy this repo on Vercel. Add `SAM_API_KEY` in Project → Settings → Environment Variables.